from django.db import models

# Create your models here.
class Order:
    pass


class OrderItem:
    pass