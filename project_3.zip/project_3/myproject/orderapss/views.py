from django.contrib.auth.models import User
from django.shortcuts import render

# Create your views here.
from datetime import datetime, timedelta
from django.shortcuts import render
from .models import Order, OrderItem

def order_history(request, user_id):
    user = User.objects.get(id=user_id)
    orders = Order.objects.filter(user=user)

    # Получаем список товаров за последние 7 дней
    week_orders = orders.filter(created_at__gte=datetime.now() - timedelta(days=7))
    week_items = OrderItem.objects.filter(order__in=week_orders).distinct('product')

    # Получаем список товаров за последние 30 дней
    month_orders = orders.filter(created_at__gte=datetime.now() - timedelta(days=30))
    month_items = OrderItem.objects.filter(order__in=month_orders).distinct('product')

    # Получаем список товаров за последние 365 дней
    year_orders = orders.filter(created_at__gte=datetime.now() - timedelta(days=365))
    year_items = OrderItem.objects.filter(order__in=year_orders).distinct('product')

    context = {
        'week_items': week_items,
        'month_items': month_items,
        'year_items': year_items,
    }
    return render(request, 'order_history.html', context)