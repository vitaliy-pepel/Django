from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse
from random import *
from django.shortcuts import render


def home(request):
    return render(request, 'home.html')


def about(request):
    return render(request, 'about.html')


def orel_reshka(request):
    return HttpResponse(choice['Orel', 'Reshka'])


def kube(request):
    return HttpResponse(str(randint(1, 7)))


def numbers(request):
    return HttpResponse(str(randint(0, 100)))


